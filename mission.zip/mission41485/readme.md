本项目用于完成OS Lab奖励实验 从U盘镜像引导加载内核程序

# 教师参考答案
请教师用户首先访问[教师项目群组](https://www.codecode.net/engintime/os-lab/bonus-lab-answer),申请权限并审核通过后，再[domain relative url](/engintime/os-lab/bonus-lab-answer/lab02-mission2.git)访问本项目的参考答案。